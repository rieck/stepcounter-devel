import numpy as np
from scipy.signal import firwin, lfilter, freqz
import matplotlib.pyplot as plt

def mean_differences(x, N=3):
    n = len(x)
    result = np.zeros(n)
    
    for i in range(n):
        # Get indices of neighbors within window, excluding point i
        start_idx = max(0, i-N)
        end_idx = min(n, i+N+1)
        neighbors = list(range(start_idx, i)) + list(range(i+1, end_idx))
        
        # Calculate differences with neighbors and take mean
        diffs = x[i] - x[neighbors]
        result[i] = np.mean(diffs)
        
    return result

def detection_function(x, N=12, t=1.2):
    # Calculate running stats and detect outliers
    outliers = []
    for i in range(0, len(x)):
        # Update running statistics
        j = max(0, i-N)
        k = min(len(x), i+N+1)
        mean = np.mean(x[j:k])
        std = np.std(x[j:k])
        
        # Detect outlier if difference from mean exceeds c * std
        diff = x[i] - mean
        if diff > t * std:
            outliers.append(i)
            
    return outliers


def remove_bounces(outliers, diffs,N=3):    
    # Initialize list for filtered outliers
    filtered = []
    
    # Add first outlier
    if len(outliers) > 0:
        filtered.append(outliers[0])
    
    # Process outliers in groups that are closer than N samples
    i = 0
    while i < len(outliers):
        # Find all outliers within N samples of current one
        group = [outliers[i]]
        j = i + 1
        while j < len(outliers) and outliers[j] - outliers[i] < N:
            group.append(outliers[j])
            j += 1
            
        # Keep the largest difference in this group
        if len(group) > 0:
            max_diff_idx = max(group, key=lambda x: diffs[x])
            filtered.append(max_diff_idx)
            
        # Move to next group
        i = j
    return filtered

def remove_small_steps(step_points, diffs, t=2000):
    return [i for i in step_points if diffs[i] > t]

def count_steps(df, *args, **kwargs):
    # Dummy: count zero crossings in Z as a naive step count
    step_points = []
    mag = np.abs(df['X']) + np.abs(df['Y']) + np.abs(df['Z'])
    diffs = mean_differences(mag)
    outliers = detection_function(diffs)
    step_points = remove_bounces(outliers, diffs)
    step_points = remove_small_steps(step_points, diffs)
    
    # Find k smallest magnitudes and their indices
    k = 5  # Number of smallest magnitudes to find
    if len(step_points) > 5:
        diffs = np.array(diffs)
        step_diffs = diffs[np.array(step_points)]
        sorted_indices = np.argsort(step_diffs)

        for i in range(k):
            diff = step_diffs[sorted_indices[i]]
            print(f"Step diff: {diff:.2f}")

    # Plot magnitude and mean differences
    plt.figure(figsize=(12, 6))
    plt.plot(mag, label='Magnitude')
    plt.plot(diffs, label='Mean Differences')
    plt.scatter(outliers, diffs[outliers], color='red', label='Peaks', zorder=5)
    plt.scatter(step_points, diffs[step_points], color='black', label='Steps', zorder=6)
    plt.xlabel('Sample Index')
    plt.ylabel('Value')
    plt.title('Acceleration Magnitude and Mean Differences')
    plt.legend()
    plt.tight_layout()
    plt.savefig('interme.pdf')
    plt.close()

    return len(step_points), step_points 