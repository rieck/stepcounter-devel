import argparse
import importlib.util
import os
import sys
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def load_algorithm(algorithm_path):
    """Dynamically load a step counter algorithm from a Python file."""
    module_name = os.path.splitext(os.path.basename(algorithm_path))[0]
    spec = importlib.util.spec_from_file_location(module_name, algorithm_path)
    if spec is None:
        raise ImportError(f"Cannot find spec for {algorithm_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(
        description="Step Counter Algorithm Comparison Framework"
    )
    parser.add_argument(
        "--algorithm", "-a", required=True, type=str,
        help="Path to the Python file implementing the step counter algorithm."
    )
    parser.add_argument(
        "--input", "-i", required=True, type=str,
        help="Path to the input CSV file (e.g., from recordings/)."
    )
    parser.add_argument(
        "--output", "-o", type=str, default="steps.pdf",
        help="Path to save the output plot image (default: steps.pdf)."
    )
    parser.add_argument(
        "--args", nargs=argparse.REMAINDER, default=[],
        help="Additional arguments to pass to the algorithm (optional)."
    )
    args = parser.parse_args()

    # Load input data
    df = pd.read_csv(args.input)

    # Load algorithm
    algo_module = load_algorithm(args.algorithm)
    if not hasattr(algo_module, "count_steps"):
        raise AttributeError(f"Algorithm module must define a 'count_steps(df, *args, **kwargs)' function.")

    # Call the algorithm's count_steps function
    result = algo_module.count_steps(df, *args.args)
    if isinstance(result, tuple) and len(result) == 2:
        step_count, step_points = result
    else:
        raise ValueError("count_steps must return a tuple: (step_count, step_points)")

    print(f"Detected steps: {step_count}")

    # Plot magnitude and steps
    mag = np.abs(df['X']) + np.abs(df['Y']) + np.abs(df['Z'])
    plt.figure(figsize=(12, 6))
    plt.plot(mag, label='Magnitude')
    if len(step_points) > 0:
        plt.scatter(step_points, mag.iloc[step_points], color='red', label='Detected Steps', zorder=5)
    plt.xlabel('Sample Index')
    plt.ylabel('Magnitude')
    plt.title('Acceleration Magnitude and Detected Steps')
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.output)
    print(f"Plot saved to {args.output}")


if __name__ == "__main__":
    main() 