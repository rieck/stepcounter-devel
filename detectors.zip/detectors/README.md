# Step Counter Algorithm Comparison Framework

This framework allows you to compare different step counting algorithms on sensor data.

## Usage

1. **Add your algorithm**: Implement a Python file in this directory (e.g., `my_algo.py`) with a function:

```python
def count_steps(df, *args, **kwargs):
    # df is a pandas DataFrame loaded from the input CSV
    # Return the number of detected steps (int)
    ...
```

2. **Run the framework**:

```sh
python detectors/framework.py --algorithm detectors/example_algo.py --input recordings/steps050-xyz-1.csv
```

- Use `--algorithm` (or `-a`) to specify the algorithm file.
- Use `--input` (or `-i`) to specify the input CSV file.
- Optionally, pass extra arguments to your algorithm after `--args`.

## Input Format

Input CSVs should have columns: `Timestamp, Index, X, Y, Z` (see `recordings/steps050-xyz-1.csv`).

## Example Algorithm
See `detectors/example_algo.py` for a template.

## Output

The framework prints the number of detected steps.

---

Elegant, extensible, and ready for your algorithms! 